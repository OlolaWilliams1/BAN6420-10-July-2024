BAN 6420 Module 1 Assignment
# Project Title : Highridge Construction Company Payment Slips

A Python and R program to facilitate the weekly payments of workers.

Raphael Wanjiku

10th July 2024

Joyce Olufunmilola Williams